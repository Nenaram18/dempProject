import { StyleSheet, Text, View } from 'react-native'
import React from 'react'

const Splash = ({ navigation }) => {
    setTimeout(() => {
        navigation.navigate('Login')
    }, 2000);


    return (
        <View style={{ flex: 1, backgroundColor: 'black', alignItems: 'center', justifyContent: 'center' }}>
            <Text style={{ fontSize: 26, color: 'white', fontWeight: 'bold' }}>Genefied</Text>
        </View>
    )
}

export default Splash

const styles = StyleSheet.create({})