import React, { useState, useEffect, useRef } from 'react';
import {
    StatusBar,
    StyleSheet,
    Text,
    View,
    Animated,
    SafeAreaView,
    ScrollView,
    TouchableOpacity,
    Platform,
    Alert,
    TextInput,
    PermissionsAndroid,
    Image,
} from 'react-native';

import ProgressLoader from 'rn-progress-loader';
import AsyncStorage from '@react-native-async-storage/async-storage';
import NetInfo from '@react-native-community/netinfo';
import axios from 'axios';
import ImageCropPicker from 'react-native-image-crop-picker';
import { launchCamera, launchImageLibrary } from 'react-native-image-picker';
import ApiCaller from '../../api/ApiCaller';


const Profile = ({ navigation }) => {
    const [imagePath, setImagePath] = useState('')
    const [isLoading, setIsLoading] = useState(false);



    return (
        <>
            <StatusBar
                backgroundColor="transparent"
            />
            <ProgressLoader
                visible={isLoading}
                isHUD={false}
                hudColor={'white'}
                color={'white'}
                isModal={true}
            />
            <SafeAreaView style={{ backgroundColor: 'black' }} />
            <View style={{ flex: 1, }}>


                <View style={styles.bodyView}>
                    <View style={styles.topHeader}>
                        <Text style={styles.titletxt}>Profile</Text>
                    </View>
                    <View style={{ flex: 1, justifyContent: 'center' }}>




                    </View>


                </View>

            </View >
        </>
    );

}

export default Profile;

const styles = StyleSheet.create({
    bodyView: {
        flex: 1,
        backgroundColor: 'white',
    },


    titletxt: {
        fontSize: 18,
        fontWeight: '800',
        color: 'white'
    },
    topHeader: {
        width: "100%",
        alignItems: 'center',
        justifyContent: 'center',
        backgroundColor: 'black',
        paddingTop: StatusBar.currentHeight + 5,
        paddingBottom: 15
    },
    btnView: {
        borderRadius: 16,
        backgroundColor: '#BA0432',
        height: 50,
        width: 100,
        alignItems: 'center',
        justifyContent: "center",
    },
    btnTxt: {
        fontSize: 14,
        fontWeight: '600',
        color: 'white'
    },
    button: {
        flexDirection: 'row',
        alignItems: 'center',
        justifyContent: 'center',
        paddingHorizontal: 24,
        marginBottom: 100
    },
    ImageBox: {
        backgroundColor: '#00000010',
        height: 300,
        width: '90%',
        alignSelf: 'center',
        borderRadius: 12,
        alignItems: 'center',
        justifyContent: 'center',
        overflow: 'hidden'
    },
    uploadBtn: {
        borderRadius: 16,
        backgroundColor: '#BA0432',
        height: 50,
        width: "60%",
        alignItems: 'center',
        justifyContent: "center",
        marginVertical: 10,
        alignSelf: 'center'
    }
});
