import React, { useState, useEffect, useRef } from 'react';
import {
    StatusBar,
    StyleSheet,
    Text,
    View,
    Animated,
    SafeAreaView,
    ScrollView,
    TouchableOpacity,
    Platform,
    Alert,
    TextInput,
    PermissionsAndroid,
    Image,
} from 'react-native';

import ProgressLoader from 'rn-progress-loader';
import AsyncStorage from '@react-native-async-storage/async-storage';
import NetInfo from '@react-native-community/netinfo';
import axios from 'axios';
import ImageCropPicker from 'react-native-image-crop-picker';
import { launchCamera, launchImageLibrary } from 'react-native-image-picker';


const Home = ({ navigation }) => {
    const [imagePath, setImagePath] = useState('')
    const [isLoading, setIsLoading] = useState(false);


    function openImageCameraPicker() {
        ImageCropPicker.openCamera({ width: 400, height: 400, cropping: true }).then(
            image => {
                if (image?.path?.length > 0) {
                    Platform.OS == 'android'
                        ?
                        setImagePath(image?.path)
                        :
                        null
                } else {
                    console.log('Camera Image Path Not Found');
                }
            },
        );
    }


    const openImageGalleryPicker_android = async () => {
        try {
            const granted = await PermissionsAndroid.check(
                PermissionsAndroid.PERMISSIONS.READ_EXTERNAL_STORAGE,
            );

            if (granted || (Platform.Version >= 33 && Platform.OS == 'android')) {
                launchImageLibrary(
                    { selectionLimit: 1, mediaType: 'photo' },
                    imageData => {

                        console.log("Image form gallery path : ", imageData?.assets[0]?.uri);
                        setImagePath(imageData?.assets[0]?.uri)
                    }
                );
            } else {

                try {
                    const granted = await PermissionsAndroid.request(
                        PermissionsAndroid.PERMISSIONS.READ_EXTERNAL_STORAGE,
                        {
                            title: 'External Storage Permission',
                            message: 'This app needs access to your storage to upload picture.',
                            buttonNegative: 'Cancel',
                            buttonPositive: 'OK',
                        },
                    );

                } catch (err) {
                    console.warn(err);
                }

            }
        } catch (err) {
            Alert.alert('Error', 'Unable to access device storage.');
        }
    };






    return (
        <>
            <StatusBar
                backgroundColor="transparent"
            />
            <ProgressLoader
                visible={isLoading}
                isHUD={false}
                hudColor={'white'}
                color={'white'}
                isModal={true}
            />
            <SafeAreaView style={{ backgroundColor: 'black' }} />
            <View style={{ flex: 1, }}>


                <View style={styles.bodyView}>
                    <View style={styles.topHeader}>
                        <Text style={styles.titletxt}>Home</Text>
                    </View>
                    <View style={{ flex: 1, justifyContent: 'center' }}>




                    </View>


                </View>

            </View >
        </>
    );

}

export default Home;

const styles = StyleSheet.create({
    bodyView: {
        flex: 1,
        backgroundColor: 'white',
    },


    titletxt: {
        fontSize: 18,
        fontWeight: '800',
        color: 'white'
    },
    topHeader: {
        width: "100%",
        alignItems: 'center',
        justifyContent: 'center',
        backgroundColor: 'black',
        paddingTop: StatusBar.currentHeight + 5,
        paddingBottom: 15
    },
    btnView: {
        borderRadius: 16,
        backgroundColor: '#BA0432',
        height: 50,
        width: 100,
        alignItems: 'center',
        justifyContent: "center",
    },
    btnTxt: {
        fontSize: 14,
        fontWeight: '600',
        color: 'white'
    },
    button: {
        flexDirection: 'row',
        alignItems: 'center',
        justifyContent: 'center',
        paddingHorizontal: 24,
        marginBottom: 100
    },
    ImageBox: {
        backgroundColor: '#00000010',
        height: 300,
        width: '90%',
        alignSelf: 'center',
        borderRadius: 12,
        alignItems: 'center',
        justifyContent: 'center',
        overflow: 'hidden'
    },
    uploadBtn: {
        borderRadius: 16,
        backgroundColor: '#BA0432',
        height: 50,
        width: "60%",
        alignItems: 'center',
        justifyContent: "center",
        marginVertical: 10,
        alignSelf: 'center'
    }
});
